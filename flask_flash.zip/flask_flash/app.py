#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      G522032
#
# Created:     20/07/2020
# Copyright:   (c) G522032 2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from flask import Flask , render_template ,flash , session ,redirect ,url_for
from flask_wtf import FlaskForm
from wtforms import StringField , SubmitField

app = Flask(__name__)
app.config['SECRET_KEY'] = 'MY KEY'


class SimpleForm(FlaskForm):
    breed =StringField("what are you breed")
    submit = SubmitField('click me')


@app.route('/', methods = ['GET', 'POST'])
def index():
    form =SimpleForm()
    if form.validate_on_submit():

        session['breed'] = form.breed.data
        flash("you just changed your breed: {session['breed']}")

        return redirect(url_for('index'))

    return render_template('index.html', form=form)

if __name__ =='__main__':
    app.run(debug = True)