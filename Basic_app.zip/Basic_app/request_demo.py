#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      G522032
#
# Created:     22/07/2020
# Copyright:   (c) G522032 2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from flask import Flask , request
app = Flask(__name__)

@app.route('/')
def index():
    user_agent = request.headers.get('User-Agent')
    return '<p>your browser is %s </p>' %user_agent

if __name__ == '__main__':
    app.run(debug = True)