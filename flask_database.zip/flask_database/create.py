from app import db , puppy

##create ##
my_puppy =puppy('rufees',5)
db.session.add(my_puppy)
db.session.commit()

#########3read#####################
all_puppies = puppy.query.all() #list of puppies objects in the table
print(all_puppies)

##select by id ##

puppy_one = puppy.query.get(1)
print(puppy_one.name)

##filters
##produce some sql code
puppy_frank = puppy.query.filter_by(name='Frankie')
print(puppy_frank.all())
#print te statement same as the  __rpr__


#############update ###########
first_puppy = puppy.query.get(1)
first_puppy.age = 10
db.session.add(first_puppy)
db.session.commit()

#####Delete
second_pup = puppy.query.get(2)
db.session.delete(second_pup)
db.session.commit()

#
all_puppies = puppy.query.all()
print(all_puppies)
