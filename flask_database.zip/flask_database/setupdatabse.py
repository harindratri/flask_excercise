from app import db , puppy
#create the table --> db table
db.create_all()

sam= puppy('sammy',3)
frank = puppy('frunky',5)

print(sam.id)
print(frank.id)

db.session.add_all([sam, frank])
db.session.commit()

print(sam.id)
print(frank.id)
